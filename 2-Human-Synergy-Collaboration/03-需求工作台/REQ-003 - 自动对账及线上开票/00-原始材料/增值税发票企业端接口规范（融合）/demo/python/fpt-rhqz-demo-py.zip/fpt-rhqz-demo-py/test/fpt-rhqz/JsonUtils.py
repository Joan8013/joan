#!/usr/bin/env python
# -*- coding:utf-8 -*-
import base64
from Utils import Utils as utils
from AesTools import MyAESCH as MyAESCH
from EncryptionUtils import Sha256Utils as Sha256Utils


class JsonUtils:

    def __init__(self):
        pass

    def getSendToTaxJson(self, interfaceCode, fpqqlsh, nsrsbh, nsrcmc, fpdm, fphm, sblx, sbbh, appid, contentPassword,
                         callback_url, lsh):
        content = ''
        sb = '{'
        sb = sb.__add__("\"interface\": {")
        sb = sb.__add__("\"globalInfo\": {")
        sb = sb.__add__("\"appId\": \"").__add__(appid).__add__("\",")
        sb = sb.__add__("\"interfaceId\": \"\",")
        sb = sb.__add__("\"interfaceCode\": \"").__add__(interfaceCode).__add__("\",")
        sb = sb.__add__("\"requestCode\": \"DZFPQZ\",")
        sb = sb.__add__("\"requestTime\": \"").__add__(utils.formatToTime()).__add__("\",")
        sb = sb.__add__("\"responseCode\": \"Ds\",")
        sb = sb.__add__("\"dataExchangeId\": \"").__add__("DZFPQZ").__add__(interfaceCode).__add__(
            utils.formatToDay()).__add__(str(utils.randNineData())).__add__("\"")
        sb = sb.__add__("},")
        sb = sb.__add__("\"returnStateInfo\": {")
        sb = sb.__add__("\"returnCode\": \"\",")
        sb = sb.__add__("\"returnMessage\": \"\"")
        sb = sb.__add__("},")
        sb = sb.__add__("\"data\": {")
        sb = sb.__add__("\"dataDescription\": {")
        sb = sb.__add__("\"zipCode\": \"0\"")
        sb = sb.__add__("},")
        sb = sb.__add__("\"content\": \"")
        if interfaceCode == utils.GP_FPKJ:
            content = content.__add__(JsonUtils().getUploadContent(nsrsbh, nsrcmc, sblx, sbbh, callback_url, lsh))
        elif interfaceCode == utils.GP_FPCX:
            content = content.__add__(JsonUtils().getSearchContent(nsrsbh, fpqqlsh))
        elif interfaceCode == utils.GP_SKSBXXCX:
            content = content.__add__(JsonUtils().getSksbxxcx(self, nsrsbh, sblx, sbbh, callback_url, lsh))
        elif interfaceCode == utils.GP_YBJGCX:
            content = content.__add__(JsonUtils().getYbjgcx(self, nsrsbh, sbbh, lsh))
            # json的报文不允许有换行，base64会产生。因此此处做去换行处理。
        content = content.replace("\r\n", "").replace("\n", "")
        sb = sb.__add__(content).__add__("\",")
        sb = sb.__add__("\"contentKey\":\"")
        contentSha256 = Sha256Utils.SHA256Encrypt(self, content)
        contentKey = MyAESCH(contentPassword).encryptBASE64(contentSha256)
        sb = sb.__add__(contentKey).__add__("\"")
        sb = sb.__add__("}")
        sb = sb.__add__("}")
        sb = sb.__add__("}")
        return sb

    """ 根据加密上传发票内容报文（发票开具） """

    @staticmethod
    def getUploadContent(nsrsbh, nsrmc, sblx, sbbh, callback_url, lsh):
        content = '{'
        content = content.__add__("\"REQUEST_COMMON_FPKJ\": {")
        content = content.__add__("\"NSRSBH\": \"" + nsrsbh + "\",")
        content = content.__add__("\"SBLX\": \"" + sblx + "\",")
        content = content.__add__("\"SBBH\": \"" + sbbh + "\",")
        content = content.__add__("\"FPQQLSH\": \"TEST" + utils.formatToTime() + "01" + "\",")
        content = content.__add__("\"ZSFS\": \"0\",")
        content = content.__add__("\"KPLX\": \"0\",")
        content = content.__add__("\"BMB_BBH\": \"32.0\",")
        content = content.__add__("\"FPLXDM\": \"026\",")
        content = content.__add__("\"XSF_NSRSBH\": \"" + nsrsbh + "\",")
        content = content.__add__("\"XSF_MC\": \"" + nsrmc + "\",")
        content = content.__add__("\"XSF_DZDH\": \"南山区蛇口、83484949\",")
        content = content.__add__("\"XSF_YHZH\": \"xx银行、88888888888\",")
        content = content.__add__("\"GMF_NSRSBH\": \"\",")
        content = content.__add__("\"GMF_MC\": \"张三\",")
        content = content.__add__("\"GMF_DZDH\": \"购买方地址、电话\",")
        content = content.__add__("\"GMF_YHZH\": \"购买方银行账号\",")
        content = content.__add__("\"GMF_SJH\": \"\",")
        content = content.__add__("\"GMF_DZYX\": \"\",")
        content = content.__add__("\"FPT_ZH\": \"\",")
        content = content.__add__("\"WX_OPENID\": \"\",")
        content = content.__add__("\"KPR\": \"开票人\",")
        content = content.__add__("\"SKR\": \"收款人\",")
        content = content.__add__("\"FHR\": \"复核人\",")
        content = content.__add__("\"YFP_DM\": \"\",")
        content = content.__add__("\"YFP_HM\": \"\",")
        content = content.__add__("\"JSHJ\": \"113\",")
        content = content.__add__("\"HJJE\": \"100\",")
        content = content.__add__("\"HJSE\": \"13\",")
        content = content.__add__("\"KCE\": \"\",")
        content = content.__add__("\"BZ\": \"json测试开票备注\",")
        content = content.__add__("\"HYLX\": \"\",")
        content = content.__add__("\"BY1\": \"\",")
        content = content.__add__("\"BY2\": \"\",")
        content = content.__add__("\"BY3\": \"\",")
        content = content.__add__("\"BY4\": \"\",")
        content = content.__add__("\"BY5\": \"\",")
        content = content.__add__("\"BY6\": \"\",")
        content = content.__add__("\"BY7\": \"\",")
        content = content.__add__("\"BY8\": \"\",")
        content = content.__add__("\"BY9\": \"\",")
        content = content.__add__("\"BY10\": \"\",")
        content = content.__add__("\"WX_ORDER_ID\": \"\",")
        content = content.__add__("\"WX_APP_ID\": \"\",")
        content = content.__add__("\"ZFB_UID\": \"\",")
        content = content.__add__("\"COMMON_FPKJ_XMXX\": [{")
        content = content.__add__("\"FPHXZ\": \"0\",")
        content = content.__add__("\"SPBM\": \"1010101050000000000\",")
        content = content.__add__("\"ZXBM\": \"\",")
        content = content.__add__("\"YHZCBS\": \"\",")
        content = content.__add__("\"LSLBS\": \"\",")
        content = content.__add__("\"ZZSTSGL\": \"\",")
        content = content.__add__("\"XMMC\": \"红高粱\",")
        content = content.__add__("\"GGXH\": \"500克\",")
        content = content.__add__("\"DW\": \"袋\",")
        content = content.__add__("\"XMSL\": \"1\",")
        content = content.__add__("\"XMDJ\": \"50\",")
        content = content.__add__("\"XMJE\": \"50\",")
        content = content.__add__("\"SL\": \"0.13\",")
        content = content.__add__("\"SE\": \"6.5\",")
        content = content.__add__("\"BY1\": \"\",")
        content = content.__add__("\"BY2\": \"\",")
        content = content.__add__("\"BY3\": \"\",")
        content = content.__add__("\"BY4\": \"\",")
        content = content.__add__("\"BY5\": \"\"},")
        content = content.__add__("{")
        content = content.__add__("\"FPHXZ\": \"0\",")
        content = content.__add__("\"SPBM\": \"1010101010000000000\",")
        content = content.__add__("\"ZXBM\": \"\",")
        content = content.__add__("\"YHZCBS\": \"\",")
        content = content.__add__("\"LSLBS\": \"\",")
        content = content.__add__("\"ZZSTSGL\": \"\",")
        content = content.__add__("\"XMMC\": \"东北大米\",")
        content = content.__add__("\"GGXH\": \"500克\",")
        content = content.__add__("\"DW\": \"袋\",")
        content = content.__add__("\"XMSL\": \"1\",")
        content = content.__add__("\"XMDJ\": \"50\",")
        content = content.__add__("\"XMJE\": \"50\",")
        content = content.__add__("\"SL\": \"0.13\",")
        content = content.__add__("\"SE\": \"6.5\",")
        content = content.__add__("\"BY1\": \"\",")
        content = content.__add__("\"BY2\": \"\",")
        content = content.__add__("\"BY3\": \"\",")
        content = content.__add__("\"BY4\": \"\",")
        content = content.__add__("\"BY5\": \"\"}],")
        content = content.__add__("\"CALLBACK_URL\": \"" + callback_url + "\",")
        content = content.__add__("\"LSH\": \"" + lsh + "\"")
        content = content.__add__("}")
        content = content.__add__("}")
        return str(base64.b64encode(content.encode('utf8')), 'utf8')

        """ 获取加密查询报文内容(发票查询报文) """

    @staticmethod
    def getSearchContent(nsrsbh, fpqqlsh):
        content = "{"
        content = content.__add__("\"REQUEST_COMMON_FPCX\":{")
        content = content.__add__("\"FPQQLSH\":\"").__add__(fpqqlsh).__add__("\",")
        content = content.__add__("\"XSF_NSRSBH\":\"").__add__(nsrsbh).__add__("\"}}")
        return str(base64.b64encode(content.encode('utf8')), 'utf8')

    """ 取加密查询报文内容(税控设备查询报文) """

    def getSksbxxcx(self, nsrsbh, sblx, sbbh, callback_url, lsh):
        content = '{'
        content = content.__add__("\"REQUEST_COMMON_SKSBXXCX\":{")
        content = content.__add__("\"NSRSBH\":\"").__add__(nsrsbh).__add__("\",")
        content = content.__add__("\"SBLX\":\"").__add__(sblx).__add__("\",")
        content = content.__add__("\"SBBH\":\"").__add__(sbbh).__add__("\",")
        content = content.__add__("\"CALLBACK_URL\":\"").__add__(callback_url).__add__("\",")
        content = content.__add__("\"LSH\":\"").__add__(lsh).__add__("\"}}")
        return str(base64.b64encode(content.encode('utf8')), 'utf8')

    """ 获取加密查询报文内容(异步请求结果查询报文) """

    def getYbjgcx(self, nsrsbh, sbbh, lsh):
        content = '{'
        content = content.__add__("\"REQUEST_COMMON_YBJGCX\":{")
        content = content.__add__("\"NSRSBH\":\"").__add__(nsrsbh).__add__("\",")
        content = content.__add__("\"SBBH\":\"").__add__(sbbh).__add__("\",")
        content = content.__add__("\"INTERFACE_CODE\":\"").__add__(utils.GP_FPKJ).__add__("\",")
        content = content.__add__("\"LSH\":\"").__add__("pk012020090418002001").__add__("\"}}")
        return str(base64.b64encode(content.encode('utf8')), 'utf8')

    # def _py_main_(self):
    #     data = self.getUploadContent('11111', '22222', '33333', '44444', '55555', '444s', '45')
    #     print("拼接的字符串为：%s" % (base64.b64decode(data).decode("utf-8")))
    #     print("当前日期", utils.formatToDay(self))

# JsonUtils()._py_main_()
