#!/usr/bin/env python
# -*- coding:utf-8 -*-
import hashlib


class Sha256Utils:

    """
        可用于 Sha256,Sha1，Md5的加密操作 SHA256Encrypt
    """
    def __init__(self):
        pass

    def SHA256Encrypt(self, str):

        sha256Data = hashlib.sha256(str.encode('utf-8')).hexdigest()
        return sha256Data

    def getMd5Str(self, str):

        md5dData = hashlib.md5(str.encode('utf-8')).hexdigest()
        return md5dData

    def getSh1Str(self, str):

        sha1Data = hashlib.sha1(str.encode('utf-8')).hexdigest()
        return sha1Data

    def _py_main_(self):
        sha256Data = self.SHA256Encrypt('我爱我的祖国')
        md5Data = self.getMd5Str('我爱我的祖国')
        sha1Data = self.getSh1Str('我爱我的祖国')
        print('sha256加密后的字符串为 %s ; md5加密字符串为 %s ; sha1加密后的字符串为： %s ; aes加密后的字符串为 %s' % (sha256Data, md5Data, sha1Data, aesDate))


# Sha256Utils()._py_main_()