#!/usr/bin/env python
# -*- coding:utf-8 -*-
import base64
from Crypto.Cipher import AES
from binascii import b2a_base64, a2b_base64


# 不支持中文
class MyAES:

    def __init__(self, key):
        self.key = key.encode('utf-8')
        self.mode = AES.MODE_ECB

    # 加密函数，如果text不足16位就用空格补足为16位，
    # 如果大于16当时不是16的倍数，那就补足为16的倍数。
    def encryptBASE64(self, text):
        text = text.encode('utf-8')
        cryptor = AES.new(self.key, self.mode)
        # 这里密钥key 长度必须为16（AES-128）,
        # 24（AES-192）,或者32 （AES-256）Bytes 长度
        # 目前AES-128 足够目前使用
        length = 16
        count = len(text)
        if count < length:
            add = (length - count)
            # \0 backspace
            # text = text + ('\0' * add)
            text = text + ('\0' * add).encode('utf-8')
        elif count > length:
            add = (length - (count % length))
            # text = text + ('\0' * add)
            text = text + ('\0' * add).encode('utf-8')
        self.ciphertext = cryptor.encrypt(text)
        # 因为AES加密时候得到的字符串不一定是ascii字符集的，输出到终端或者保存时候可能存在问题
        # 所以这里统一把加密后的字符串转化为16进制字符串
        return b2a_base64(self.ciphertext).decode('utf8')

    # 解密后，去掉补足的空格用strip() 去掉
    def decryptBASE64(self, text):
        cryptor = AES.new(self.key, self.mode)
        plain_text = cryptor.decrypt(a2b_base64(text.encode('utf-8')))
        # return plain_text.rstrip('\0')
        return bytes.decode(plain_text).rstrip('\0')


# 支持中文
class MyAESCH:
    def __init__(self, key):
        self.key = key  # 初始化密钥
        self.length = AES.block_size  # 初始化数据块大小
        self.aes = AES.new(self.key.encode("utf8"), AES.MODE_ECB)  # 初始化AES,ECB模式的实例
        # 截断函数，去除填充的字符
        self.unpad = lambda date: date[0:-ord(date[-1])]

    def pad(self, text):
        """
        #填充函数，使被加密数据的字节码长度是block_size的整数倍
        """
        count = len(text.encode('utf-8'))
        add = self.length - (count % self.length)
        entext = text + (chr(add) * add)
        return entext

    def encryptBASE64(self, encrData):  # 加密函数
        res = self.aes.encrypt(self.pad(encrData).encode("utf8"))
        msg = str(base64.b64encode(res), encoding="utf8")
        return msg

    def decryptBASE64(self, decrData):  # 解密函数
        res = base64.decodebytes(decrData.encode("utf8"))
        msg = self.aes.decrypt(res).decode("utf8")
        return self.unpad(msg)


# if __name__ == '__main__':
#     pc = MyAES('F6AD954A498AEDBE')  # 初始化密钥
#     e = pc.encryptBASE64("我爱我的祖国")  # 加密
#     d = pc.decryptBASE64(e)  # 解密
#     print("加密:", e)
#     print("解密:", d)


# if __name__ == '__main__':
# eg = MyAESCH("F6AD954A498AEDBE")  # 这里密钥的长度必须是16的倍数
# res = eg.encryptBASE64("我爱我的祖国")
# print(res)
# print(eg.decryptBASE64(res))