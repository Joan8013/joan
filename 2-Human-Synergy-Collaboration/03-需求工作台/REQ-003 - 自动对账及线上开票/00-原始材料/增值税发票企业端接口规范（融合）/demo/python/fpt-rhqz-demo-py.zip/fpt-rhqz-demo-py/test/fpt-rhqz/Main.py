#!/usr/bin/env python
# -*- coding:utf-8 -*-
import requests_pkcs12

from Utils import Utils as utils
from JsonUtils import JsonUtils as jsonUtils


class Main:

    # 声明全局变量 初始化开始时间
    headerpy = {'content-Type': 'application/json;charset=UTF-8'}
    startDate = ''
    # 初始化地址
    requestUrl = "https://dev.fapiao.com:18944/fpt-rhqz/prepose/"
    appid = ""
    contentPassword = ""
    nsrsbh = ""
    nsrmc = ""
    sbbh = ""
    callback_url = "http://192.168.72.187:8080/demo-rhqz/callBackDemoAction"
    lsh = ""
    # 开具报文的FPQQLSH是动态生成的，如果要查询请填写已开具的固定值  需要查询发票的流水号
    fpqqlsh = ""
    fpdm = ""
    fphm = ""

    # 1 - 税控盘、2 - 金税盘、3 - UKey、4 - 老税控服务器、5 - 新型税控服务器
    # sblx = utils.SBLX_1
    # sblx = utils.SBLX_2
    # sblx = utils.SBLX_3
    # sblx = utils.SBLX_4
    sblx = utils.SBLX_5
    # 通过注释选择接口 发票开具
    interfaceCode = utils.GP_FPKJ
    # 发票查询
    # interfaceCode = Utils.GP_FPCX
    # 税控设备信息查询
    # interfaceCode = Utils.GP_SKSBXXCX
    # 异步请求结果查询
    # interfaceCode = Utils.GP_YBJGCX

    requestData = ""

    def __init__(self):
        pass

    # 组装请求报文
    def getRequestMessage(self):

        if self.sblx == utils.SBLX_1:
            self.appid = "667bf7c79996c7a507af365a8f340a6f9009c519d28a59ae3be23cc86c2e1630"
            # AES加密密钥
            self.contentPassword = "F6AD954A498AEDBE"
            self.nsrsbh = "500102010004011"
            self.nsrmc = "升级版测试用户4011"
            self.sbbh = "499000138208"

            self.fpqqlsh = "TEST2020071715000010"
            self.fpdm = "050000000004"
            self.fphm = "44533013"
            if self.interfaceCode == utils.GP_FPKJ:
                # 拼接开具的方法名
                self.callback_url = self.callback_url + "?method=FPKJ"
            # 如果要查询相关接口请不要动态生成，请填写请求过的固定值
            self.lsh = "pk0" + self.sblx + utils.formatToTime() + "01"
            print("异步请求LSH：【" + self.lsh + "】")
            self.requestData = jsonUtils.getSendToTaxJson(self, self.interfaceCode, self.fpqqlsh, self.nsrsbh, self.nsrmc,
                                                          self.fpdm, self.fphm, self.sblx, self.sbbh, self.appid,
                                                          self.contentPassword, self.callback_url, self.lsh)
        elif self.sblx == utils.SBLX_3:
            # ukey需要根据用户自己的测试设备进行配置
            self.callback_url = ""
            self.requestData = jsonUtils.getSendToTaxJson(self, self.interfaceCode, self.fpqqlsh, self.nsrsbh,
                                                          self.nsrmc, self.fpdm, self.fphm, self.sblx, self.sbbh,
                                                          self.appid, self.contentPassword, self.callback_url, self.lsh)
        elif self.sblx == utils.SBLX_4:
            # appid
            self.appid = "6d29f136114544bcc73edcce960c430231183cc192c433e2b9ebcad56e8ceb08"
            # AES加密密钥
            self.contentPassword = "5EE6C2C11DD421F2"
            self.nsrsbh = "110109500321655"
            self.nsrmc = "百旺电子测试2"

            self.fpqqlsh = "TEST2020083114374201"
            self.fpdm = "050003521107"
            self.fphm = "35662145"

            self.callback_url = ""
            self.requestData = jsonUtils.getSendToTaxJson(self, self.interfaceCode, self.fpqqlsh, self.nsrsbh, self.nsrmc,
                                                          self.fpdm, self.fphm, self.sblx, self.sbbh,
                                                          self.appid, self.contentPassword, self.callback_url, self.lsh)
        elif self.sblx == utils.SBLX_5:
            # appid
            self.appid = "c288b35967a9a36fc897e89b01805451110d88507ce1aa1ab31756d872504767"
            # AES加密密钥
            self.contentPassword = "80AB94991453FA0D"
            self.nsrsbh = "110109500321668"
            self.nsrmc = "新税控测试1668"
            self.sbbh = "214324531769"

            self.fpqqlsh = "xsk01102020061000012"
            self.fpdm = "088881200610"
            self.fphm = "17083768"

            self.callback_url = ""

            self.requestData = jsonUtils.getSendToTaxJson(self, self.interfaceCode, self.fpqqlsh, self.nsrsbh, self.nsrmc,
                                                          self.fpdm, self.fphm, self.sblx, self.sbbh,
                                                          self.appid, self.contentPassword, self.callback_url, self.lsh)
        else:
            # 如果是没有设备类型的接口随意选取测试账号进行验证
            pass

        print("组装报文完毕,请求报文为:" + self.requestData + ",开始请求。")
        # 开始请求接口
        pkcs12_filename = 'E:\\sz\\testISSUE.pfx'
        pkcs12_password = '123456'
        datas = self.requestData
        res = requests_pkcs12.post(url=self.requestUrl, headers=self.headerpy, data=datas, timeout=5,
                                   pkcs12_filename=pkcs12_filename, pkcs12_password=pkcs12_password, verify=False)
        print(res.text)