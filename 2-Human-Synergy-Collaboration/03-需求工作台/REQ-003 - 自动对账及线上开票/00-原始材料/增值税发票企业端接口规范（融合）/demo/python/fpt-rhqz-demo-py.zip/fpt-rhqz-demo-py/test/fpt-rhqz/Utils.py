#!/usr/bin/env python
# -*- coding:utf-8 -*-
import datetime
import random
class Utils:

    # 全局变量1
    SBLX_1 = "1"
    SBLX_2 = "2"
    SBLX_3 = "3"
    SBLX_4 = "4"
    SBLX_5 = "5"
    # 发票开具
    GP_FPKJ = "GP_FPKJ"
    # 发票查询
    GP_FPCX = "GP_FPCX"
    # 税控设备信息查询
    GP_SKSBXXCX = "GP_SKSBXXCX"
    # 异步请求结果查询
    GP_YBJGCX = "GP_YBJGCX"

    def __init__(self):
        pass

    """ 获取指定格式时间(yyyy-MM-dd) """

    @staticmethod
    def formatToDay():
       return datetime.datetime.now().strftime("%Y-%m-%d")

    """ 获取指定格式时间(yyyyMMddHHmmss) """
    @staticmethod
    def formatToTime():
        return datetime.datetime.now().strftime('%Y%m%d%H%M%S')

    """ 获取9位随机数 """
    @staticmethod
    def randNineData():
        return random.randint(100000000,999999999)

    """ 获取5位随机数 """
    @staticmethod
    def randFiveData():
        return random.randint(10000, 99999)

    """ 获取4位随机数 """
    @staticmethod
    def randData():
        return random.randint(1000, 9999)

    def _py_main(self):
        print(" 系统当前日期为：%s " % (self.randFiveData(self)))

# Utils()._py_main()