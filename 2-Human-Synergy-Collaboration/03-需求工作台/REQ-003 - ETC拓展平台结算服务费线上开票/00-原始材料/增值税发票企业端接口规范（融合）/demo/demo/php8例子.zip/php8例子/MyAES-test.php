﻿<?php include 'MyAES.php';?>

<?php
$strSource="123456";
$strTest = hash('sha256',$strSource);//
echo "哈希值:" . $strTest . "<br />";

$strPassword = "48E92223495F210A";
$myAES = new MyAES();

$str1=$myAES->encrypt($strTest, $strPassword);
echo "aes密文：" . $str1 . "<br />";
$str2=$myAES->decrypt($str1, $strPassword);

echo "aes解密：" . $str2 . "<br />";

?>