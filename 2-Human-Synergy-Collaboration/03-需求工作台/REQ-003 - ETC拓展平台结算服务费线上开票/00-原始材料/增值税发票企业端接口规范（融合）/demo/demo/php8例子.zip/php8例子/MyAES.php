﻿<?php
/**
 * AES128加解密类
 * @author dy
 *
 */

class MyAES{
	
	public function encrypt($str,$key){
		//AES-128-ECB 模式的加密
		$screct_key = $key;  
		$str = trim($str); 
		$method = "AES-128-ECB";		
				
		$str= $this->addPKCs7Padding($str);		
		
		//使用 OpenssL 进行加密，AES-128-ECB 模式
		$encrypted =openssl_encrypt($str,'AES-128-ECB',$screct_key, OPENSSL_RAW_DATA);//返回加密结果并进行 base64 编码
		return base64_encode($encrypted);
	}

    public function decrypt($str, $key){
        $screct_key = $key;
        $str = base64_decode($str);
        //$screct_key = base64_decode($screct_key);        
        $encrypt_str =  openssl_decrypt($str,'AES-128-ECB',$screct_key, OPENSSL_RAW_DATA);
        //$encrypt_str = trim($encrypt_str);
        $encrypt_str = $this->stripPKSC7Padding($encrypt_str);
        return $encrypt_str;
    }


   public function addPKCs7Padding($source){
	   $source = trim($source);
	   $block = 16;// AES 块大小是 16 字节(对于 AES-128)
	   $pad=$block-(strlen($source)%$block);
	   if($pad< $block){
		   $char = chr($pad);
		   $source .=str_repeat($char,$pad);//使用 PKCS7 填充
	   }
      return $source;
   }
   
    /**
     * 移去填充算法
     * @param string $source
     * @return string
     */
    function stripPKSC7Padding($source){		
        $source = trim($source);		
        $char = substr($source, -1);     		
        $num = ord($char);		
		if($num!=62)return $source;				
        $source = substr($source,0,-$num);	        	
        return $source;
    }



}
?>
