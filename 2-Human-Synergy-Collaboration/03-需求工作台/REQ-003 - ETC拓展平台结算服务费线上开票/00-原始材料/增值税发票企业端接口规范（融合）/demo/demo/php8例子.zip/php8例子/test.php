<?php include 'MyAES.php';?>
<?php

test("");

function test($value='')
{
	    $url = 'https://dev.fapiao.com:19444/fpt-rhqz/prepose';   
		$content = base64_encode(cresteData());		
		
		//$dataToEncrypt = md5($content);
		$strHash=hash('sha256',$content);
		
		$strPassword = '48E92223495F210A';		
        $myAES = new MyAES();
        $contentKey=$myAES->encrypt($strHash, $strPassword);
        
		//$contentKey = encrypt($dataToEncrypt,$key);

		$data = '{
		    "interface":{
		        "globalInfo":{
		            "appId":"2d9688c1e9a68a8da702ffcc75f90226f0d8c7ea71076313d1088f50a8493093",
		            "interfaceId":"",
		            "interfaceCode":"GP_FPKJ",
		            "requestCode":"DZFPQZ",
		            "requestTime":"2020-07-21 09:58:53",
		            "responseCode":"DS",
		            "dataExchangeId":"DZFPQZDFXJ10012020072198A6123D0"
		        },
		        "returnStateInfo":{
		            "returnCode":"",
		            "returnMessage":""
		        },
		        "data":{
		            "dataDescription":{
		                "zipCode":"0"
		            },
		            "content":"'.$content.'",
		            "contentKey":"'.$contentKey.'"
		        }
		    }
		}';   
		
		
         
		$headers = array("Content-type: application/json;charset='utf-8'", "Accept: application/json", 
		    );
		$ret = curl_https($url, $data, $headers, 5);
		
		print($ret);
}


function curl_https($url, $data, $header=array(), $timeout=30){   
    $ch = curl_init();   
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false); // 跳过证书检查   
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 2); // 从证书中检查SSL加密算法是否存在   
    curl_setopt($ch, CURLOPT_URL, $url);   
    curl_setopt($ch, CURLOPT_HTTPHEADER, $header);   
    curl_setopt($ch, CURLOPT_POST, true);   
    curl_setopt($ch, CURLOPT_POSTFIELDS, $data);   
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);   
    curl_setopt($ch, CURLOPT_TIMEOUT, $timeout);   
    $response = curl_exec($ch);   
    if($error=curl_error($ch)){   
        die($error);   
    }   
    curl_close($ch);   
    return $response;   
  
} 

/*
 function encrypt($str, $key){
	  $screct_key = $key;
    //$screct_key = base64_decode($screct_key);
    $str = trim($str);
    $str = $this->addPKCS7Padding($str);
    $iv = mcrypt_create_iv(mcrypt_get_iv_size(MCRYPT_RIJNDAEL_128,MCRYPT_MODE_ECB),MCRYPT_RAND);
    $encrypt_str =  mcrypt_encrypt(MCRYPT_RIJNDAEL_128, $screct_key, $str, MCRYPT_MODE_ECB, $iv);
    return base64_encode($encrypt_str);
}

 function addPKCS7Padding($source){
    $source = trim($source);
    $block = mcrypt_get_block_size('rijndael-128', 'ecb');
    $pad = $block - (strlen($source) % $block);
    if ($pad <= $block) {
        $char = chr($pad);
        $source .= str_repeat($char, $pad);
    }
    return $source;
}
*/

function cresteData()
{
	$data = '{
		"REQUEST_COMMON_FPKJ": {
			"SBLX": "6",
			"SBBH": "",
			"FPQQLSH": "ceshi202310201041",
			"KPZDDM": "",
			"FPLXDM": "030",
			"KPLX": "0",
			"BMB_BBH": "",
			"ZSFS": "0",
			"ZSFSXX":{},
			"XSF_NSRSBH":"914402023073111101",
			"XSF_MC":"国票虚拟数电企业",
			"XSF_DZDH": "销售方地址13652638599",
			"XSF_DZ":"",
			"XSF_DH":"",
			"XSF_YHZH": "41052136245345345453",
			"XSF_KHH":"",
			"XSF_ZH":"",
			"GMF_NSRSBH": "",
			"GMF_MC": "123",
			"GMF_DZDH": "购买方地址53413213244534",
			"GMF_DZ":"",
			"GMF_DH":"",
			"GMF_YHZH": "1545341313435123135435435",
			"GMF_KHH":"",
			"GMF_ZH":"",
			"GMF_SJH": "",
			"GMF_DZYX": "596529063@qq.com",
			"FPT_ZH": "",
			"WX_OPENID": "",
			"KPR": "开票人",
			"SKR": "63",
			"FHR": "66",
			"YFP_DM": "",
			"YFP_HM": "",
			"YFP_LX":"",
			"YFP_RQ":"",
			"CHYYDM":"",
			"SSLKJLY":"",
			"JSHJ": "103",
			"HJJE": "100",
			"HJSE": "3",
			"KCE": "",
			"BZ": "7855",
			"BY1": "",
			"BY2": "",
			"BY3": "",
			"BY4": "",
			"BY5": "",
			"BY6": "",
			"BY7": "",
			"BY8": "",
			"BY9": "",
			"BY10": "",
			"WX_ORDER_ID": "",
			"WX_APP_ID": "",
			"ZFB_UID": "",
			"TSPZ": "00",
			“TSPZXX”:"",
			"TDYS":"",
			"QJ_ORDER_ID": "",
			"QDBZ": "0",
			"TZDBH": "",
			"HZQRDUUID": "",
			"JBRZJHM": "",
			"JBRZJZLDM": "",
			"JBRGJDM": "",
			"JBRZRRNSRSBH": "",
			"JBRXM": "",
			"GMF_ZRRBS": "",
			"SFZSGMFYHZH": "",
			"SFZSXSFYHZH": "",
			"COMMON_FPKJ_XMXX": [{
				"FPHXZ": "0",
				"SPBM": "3070402000000000000",
				"ZXBM": "",
				"YHZCBS": "",
				"LSLBS": "",
				"ZZSTSGL": "",
				"XMMC": "住宿",
				"GGXH": "",
				"DW": "",
				"XMSL": "",
				"XMDJ": "",
				"XMJE": "100",
				"SL": "0.03",
				"SE": "3",
				"BY1": "",
				"BY2": "",
				"BY3": "",
				"BY4": "",
				"BY5": ""
			}],
			"CALLBACK_URL": "",
			"LSH": ""
		}
	}';
	return $data;
}